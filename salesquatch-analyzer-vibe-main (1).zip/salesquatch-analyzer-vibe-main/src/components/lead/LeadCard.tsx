
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { 
  Building2, 
  Globe, 
  Users, 
  DollarSign, 
  MapPin, 
  Mail, 
  Phone,
  Star,
  TrendingUp,
  ExternalLink
} from 'lucide-react';
import { Lead } from '../../types/lead';

interface LeadCardProps {
  lead: Lead;
}

const LeadCard: React.FC<LeadCardProps> = ({ lead }) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'contacted': return 'bg-purple-100 text-purple-800';
      case 'qualified': return 'bg-green-100 text-green-800';
      case 'nurturing': return 'bg-yellow-100 text-yellow-800';
      case 'closed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Building2 className="h-5 w-5" />
              {lead.companyName}
            </CardTitle>
            <div className="flex items-center gap-2 mt-2">
              <Globe className="h-4 w-4 text-gray-500" />
              <a 
                href={lead.website} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline flex items-center gap-1"
              >
                {lead.website}
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className={`text-2xl font-bold ${getScoreColor(lead.score)}`}>
              {lead.score}
            </div>
            <div className="flex gap-2">
              <Badge className={getPriorityColor(lead.priority)}>
                {lead.priority.toUpperCase()}
              </Badge>
              <Badge className={getStatusColor(lead.status)}>
                {lead.status.toUpperCase()}
              </Badge>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <p className="text-gray-600">{lead.description}</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-gray-500" />
            <span className="text-sm">{lead.employeeCount}</span>
          </div>
          <div className="flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-gray-500" />
            <span className="text-sm">{lead.revenue}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-gray-500" />
            <span className="text-sm">{lead.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Building2 className="h-4 w-4 text-gray-500" />
            <span className="text-sm">{lead.industry}</span>
          </div>
        </div>

        <Separator />

        <div>
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <Star className="h-4 w-4" />
            Score Breakdown
          </h4>
          <div className="space-y-2">
            {Object.entries(lead.scoreBreakdown).map(([key, value]) => (
              <div key={key} className="flex justify-between items-center">
                <span className="text-sm capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                <div className="flex items-center gap-2 w-32">
                  <Progress value={value} className="flex-1" />
                  <span className="text-sm font-medium w-8">{value}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        <div>
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Enriched Data
          </h4>
          
          <div className="space-y-3">
            <div>
              <span className="text-sm font-medium">Technologies:</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {lead.enrichedData.technologies.map((tech, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div>
              <span className="text-sm font-medium">Social Media:</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {lead.enrichedData.socialMediaPresence.map((platform, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {platform}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div>
              <span className="text-sm font-medium">Funding:</span>
              <p className="text-sm text-gray-600 mt-1">{lead.enrichedData.fundingStatus}</p>
            </div>

            {lead.enrichedData.recentNews.length > 0 && (
              <div>
                <span className="text-sm font-medium">Recent News:</span>
                <ul className="text-sm text-gray-600 mt-1 list-disc list-inside">
                  {lead.enrichedData.recentNews.map((news, index) => (
                    <li key={index}>{news}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        <Separator />

        <div className="flex justify-between items-center">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm">
              <Mail className="h-4 w-4 text-gray-500" />
              <a href={`mailto:${lead.contactEmail}`} className="text-blue-600 hover:underline">
                {lead.contactEmail}
              </a>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4 text-gray-500" />
              <a href={`tel:${lead.contactPhone}`} className="text-blue-600 hover:underline">
                {lead.contactPhone}
              </a>
            </div>
          </div>
          <Button>
            Contact Lead
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default LeadCard;
