
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Key, ExternalLink, Info } from 'lucide-react';

interface ApiKeyInputProps {
  onApiKeySet: (apiKey: string) => void;
  hasApiKey: boolean;
}

const ApiKeyInput: React.FC<ApiKeyInputProps> = ({ onApiKeySet, hasApiKey }) => {
  const [apiKey, setApiKey] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKey.trim()) return;

    setIsLoading(true);
    // Simple validation - just check if it looks like a Hugging Face token
    if (apiKey.startsWith('hf_')) {
      onApiKeySet(apiKey);
      localStorage.setItem('hf_api_key', apiKey);
    } else {
      alert('Please enter a valid Hugging Face API key (starts with "hf_")');
    }
    setIsLoading(false);
  };

  if (hasApiKey) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          ✅ AI is connected and ready! Your leads will now be analyzed with real AI.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Key className="h-5 w-5" />
          Connect AI Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Alert className="mb-4">
          <Info className="h-4 w-4" />
          <AlertDescription>
            To enable real AI-powered lead analysis, you need a free Hugging Face API key.
            <br />
            <a 
              href="https://huggingface.co/settings/tokens" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline inline-flex items-center gap-1 mt-2"
            >
              Get your free API key here <ExternalLink className="h-3 w-3" />
            </a>
          </AlertDescription>
        </Alert>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="apiKey">Hugging Face API Key</Label>
            <Input
              id="apiKey"
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="hf_xxxxxxxxxxxxxxxxxxxx"
              required
            />
          </div>
          
          <Button type="submit" disabled={isLoading || !apiKey.trim()}>
            {isLoading ? 'Connecting...' : 'Connect AI'}
          </Button>
        </form>
        
        <div className="mt-4 text-sm text-gray-600">
          <p><strong>Why Hugging Face?</strong></p>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Completely free to use</li>
            <li>No credit card required</li>
            <li>Access to state-of-the-art AI models</li>
            <li>Your API key is stored locally in your browser</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default ApiKeyInput;
