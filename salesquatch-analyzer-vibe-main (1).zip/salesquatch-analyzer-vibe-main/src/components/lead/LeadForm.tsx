import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { Plus, Zap, Loader2 } from 'lucide-react';
import { Lead } from '../../types/lead';
import { AIService } from '../../services/aiService';

interface LeadFormProps {
  onAddLead: (lead: Lead) => void;
  aiService?: AIService;
}

const LeadForm: React.FC<LeadFormProps> = ({ onAddLead, aiService }) => {
  const [formData, setFormData] = useState({
    companyName: '',
    website: '',
    industry: '',
    employeeCount: '',
    revenue: '',
    location: '',
    contactEmail: '',
    contactPhone: '',
    description: ''
  });
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const generateAIScore = () => {
    // Simulate AI scoring algorithm
    const baseScore = Math.floor(Math.random() * 30) + 60; // 60-90 range
    const industryBonus = ['Software', 'Technology', 'SaaS'].includes(formData.industry) ? 10 : 0;
    const sizeBonus = ['50-200', '200-500', '500+'].includes(formData.employeeCount) ? 5 : 0;
    
    return Math.min(100, baseScore + industryBonus + sizeBonus);
  };

  const generateScoreBreakdown = (totalScore: number) => {
    const variation = 10;
    return {
      industryMatch: Math.max(0, Math.min(100, totalScore + (Math.random() - 0.5) * variation)),
      companySize: Math.max(0, Math.min(100, totalScore + (Math.random() - 0.5) * variation)),
      revenue: Math.max(0, Math.min(100, totalScore + (Math.random() - 0.5) * variation)),
      technology: Math.max(0, Math.min(100, totalScore + (Math.random() - 0.5) * variation)),
      engagement: Math.max(0, Math.min(100, totalScore + (Math.random() - 0.5) * variation))
    };
  };

  const generateEnrichedData = () => {
    const technologies = ['React', 'Node.js', 'Python', 'AWS', 'MongoDB', 'PostgreSQL', 'Docker', 'Kubernetes'];
    const socialMedia = ['LinkedIn', 'Twitter', 'Facebook', 'Instagram', 'YouTube'];
    const competitors = ['Competitor A', 'Competitor B', 'Competitor C'];
    const news = ['Recent product launch', 'New partnership announced', 'Expansion into new market'];

    return {
      socialMediaPresence: socialMedia.slice(0, Math.floor(Math.random() * 3) + 1),
      technologies: technologies.slice(0, Math.floor(Math.random() * 4) + 2),
      fundingStatus: ['Bootstrapped', 'Seed - $1M raised', 'Series A - $5M raised', 'Series B - $15M raised'][Math.floor(Math.random() * 4)],
      competitors: competitors.slice(0, Math.floor(Math.random() * 2) + 1),
      recentNews: news.slice(0, Math.floor(Math.random() * 2) + 1)
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.companyName || !formData.website || !formData.industry) {
      toast({
        title: "Missing Information",
        description: "Please fill in company name, website, and industry.",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      let analysisResult;
      
      if (aiService) {
        // Use real AI analysis
        analysisResult = await aiService.analyzeCompany(formData);
        toast({
          title: "AI Analysis Complete",
          description: "Your lead has been analyzed using real AI!",
        });
      } else {
        // Fallback to simulation
        const score = generateAIScore();
        analysisResult = {
          score,
          scoreBreakdown: generateScoreBreakdown(score),
          enrichedData: generateEnrichedData(),
          priority: score >= 85 ? 'high' : score >= 70 ? 'medium' : 'low' as const
        };
      }

      const newLead: Lead = {
        id: Date.now().toString(),
        ...formData,
        score: analysisResult.score,
        scoreBreakdown: analysisResult.scoreBreakdown,
        enrichedData: analysisResult.enrichedData,
        priority: analysisResult.priority,
        status: 'new'
      };

      onAddLead(newLead);
      
      // Reset form
      setFormData({
        companyName: '',
        website: '',
        industry: '',
        employeeCount: '',
        revenue: '',
        location: '',
        contactEmail: '',
        contactPhone: '',
        description: ''
      });

      toast({
        title: "Lead Added Successfully",
        description: `${newLead.companyName} has been added with a score of ${analysisResult.score}.`
      });
    } catch (error) {
      console.error('Error analyzing lead:', error);
      toast({
        title: "Analysis Error",
        description: "There was an issue analyzing the lead. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="h-5 w-5" />
          Add New Lead
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">Company Name *</Label>
              <Input
                id="companyName"
                value={formData.companyName}
                onChange={(e) => handleInputChange('companyName', e.target.value)}
                placeholder="Enter company name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website">Website *</Label>
              <Input
                id="website"
                value={formData.website}
                onChange={(e) => handleInputChange('website', e.target.value)}
                placeholder="https://company.com"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="industry">Industry *</Label>
              <Select value={formData.industry} onValueChange={(value) => handleInputChange('industry', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Software">Software</SelectItem>
                  <SelectItem value="Technology">Technology</SelectItem>
                  <SelectItem value="SaaS">SaaS</SelectItem>
                  <SelectItem value="Healthcare">Healthcare</SelectItem>
                  <SelectItem value="Finance">Finance</SelectItem>
                  <SelectItem value="E-commerce">E-commerce</SelectItem>
                  <SelectItem value="Manufacturing">Manufacturing</SelectItem>
                  <SelectItem value="Consulting">Consulting</SelectItem>
                  <SelectItem value="Education">Education</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="employeeCount">Employee Count</Label>
              <Select value={formData.employeeCount} onValueChange={(value) => handleInputChange('employeeCount', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select employee count" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1-10">1-10</SelectItem>
                  <SelectItem value="11-50">11-50</SelectItem>
                  <SelectItem value="51-200">51-200</SelectItem>
                  <SelectItem value="201-500">201-500</SelectItem>
                  <SelectItem value="501-1000">501-1000</SelectItem>
                  <SelectItem value="1000+">1000+</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="revenue">Annual Revenue</Label>
              <Select value={formData.revenue} onValueChange={(value) => handleInputChange('revenue', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select revenue range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="<$1M">Less than $1M</SelectItem>
                  <SelectItem value="$1M-$5M">$1M - $5M</SelectItem>
                  <SelectItem value="$5M-$10M">$5M - $10M</SelectItem>
                  <SelectItem value="$10M-$50M">$10M - $50M</SelectItem>
                  <SelectItem value="$50M-$100M">$50M - $100M</SelectItem>
                  <SelectItem value="$100M+">$100M+</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleInputChange('location', e.target.value)}
                placeholder="City, State/Country"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contactEmail">Contact Email</Label>
              <Input
                id="contactEmail"
                type="email"
                value={formData.contactEmail}
                onChange={(e) => handleInputChange('contactEmail', e.target.value)}
                placeholder="contact@company.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contactPhone">Contact Phone</Label>
              <Input
                id="contactPhone"
                value={formData.contactPhone}
                onChange={(e) => handleInputChange('contactPhone', e.target.value)}
                placeholder="+1-555-0123"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Company Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Brief description of the company and what they do..."
              className="min-h-[100px]"
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="submit" className="flex-1" disabled={isAnalyzing}>
              {isAnalyzing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  {aiService ? 'AI Analyzing...' : 'Processing...'}
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  Add Lead & {aiService ? 'AI Analyze' : 'Generate Score'}
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default LeadForm;
