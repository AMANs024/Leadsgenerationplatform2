
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import { Target, Building2, Plus } from 'lucide-react';
import { Lead } from '../types/lead';
import { sampleLeads } from '../data/sampleLeads';
import { AIService } from '../services/aiService';
import LeadCard from './lead/LeadCard';
import LeadForm from './lead/LeadForm';
import AnalyticsDashboard from './lead/AnalyticsDashboard';
import StatsCards from './lead/StatsCards';
import SearchAndFilter from './lead/SearchAndFilter';
import ApiKeyInput from './lead/ApiKeyInput';

const LeadEnrichmentPlatform = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');
  const [aiService, setAiService] = useState<AIService | null>(null);
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    // Check if API key is stored in localStorage
    const storedApiKey = localStorage.getItem('hf_api_key');
    if (storedApiKey) {
      setAiService(new AIService(storedApiKey));
      setHasApiKey(true);
    }
  }, []);

  const handleApiKeySet = (apiKey: string) => {
    setAiService(new AIService(apiKey));
    setHasApiKey(true);
    toast({
      title: "AI Connected!",
      description: "Your leads will now be analyzed using real AI models.",
    });
  };

  const handleAddLead = (newLead: Lead) => {
    setLeads([newLead, ...leads]);
  };

  const loadSampleData = () => {
    setLeads(sampleLeads);
    toast({
      title: "Sample Data Loaded",
      description: "3 sample leads with enriched data have been loaded."
    });
  };

  const filteredLeads = leads.filter(lead => {
    const matchesSearch = lead.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lead.industry.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPriority = filterPriority === 'all' || lead.priority === filterPriority;
    return matchesSearch && matchesPriority;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-3">
            <Target className="text-blue-600" />
            Lead Enrichment Platform
          </h1>
          <p className="text-xl text-gray-600">
            {hasApiKey ? 'AI-Powered Lead Generation & Scoring' : 'Connect AI for Enhanced Lead Analysis'}
          </p>
        </div>

        {/* API Key Input */}
        <ApiKeyInput onApiKeySet={handleApiKeySet} hasApiKey={hasApiKey} />

        {/* Quick Stats */}
        <StatsCards leads={leads} />

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="add-lead">Add Lead</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Search and Filter */}
            <SearchAndFilter
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              filterPriority={filterPriority}
              setFilterPriority={setFilterPriority}
              onLoadSampleData={loadSampleData}
            />

            {/* Leads List */}
            <div className="space-y-4">
              {filteredLeads.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No leads found</h3>
                    <p className="text-gray-500 mb-4">Get started by adding your first lead or loading sample data.</p>
                    <Button onClick={() => setActiveTab('add-lead')}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Your First Lead
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                filteredLeads.map((lead) => (
                  <LeadCard key={lead.id} lead={lead} />
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="add-lead" className="space-y-6">
            <LeadForm onAddLead={handleAddLead} aiService={aiService} />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <AnalyticsDashboard leads={leads} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default LeadEnrichmentPlatform;
