
import LeadEnrichmentPlatform from '@/components/LeadEnrichmentPlatform';

const Index = () => {
  return <LeadEnrichmentPlatform />;
};

export default Index;
