
export interface Lead {
  id: string;
  companyName: string;
  website: string;
  industry: string;
  employeeCount: string;
  revenue: string;
  location: string;
  contactEmail: string;
  contactPhone: string;
  description: string;
  score: number;
  scoreBreakdown: {
    industryMatch: number;
    companySize: number;
    revenue: number;
    technology: number;
    engagement: number;
  };
  enrichedData: {
    socialMediaPresence: string[];
    technologies: string[];
    fundingStatus: string;
    competitors: string[];
    recentNews: string[];
  };
  priority: 'high' | 'medium' | 'low';
  status: 'new' | 'contacted' | 'qualified' | 'nurturing' | 'closed';
}
