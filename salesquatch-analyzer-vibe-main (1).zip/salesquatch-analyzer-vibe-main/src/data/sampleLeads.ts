
import { Lead } from '../types/lead';

export const sampleLeads: Lead[] = [
  {
    id: '1',
    companyName: 'TechFlow Solutions',
    website: 'https://techflow.com',
    industry: 'Software',
    employeeCount: '50-200',
    revenue: '$5M-$10M',
    location: 'San Francisco, CA',
    contactEmail: 'contact@techflow.com',
    contactPhone: '+1-555-0123',
    description: 'Cloud-based workflow automation platform for enterprises',
    score: 92,
    scoreBreakdown: {
      industryMatch: 95,
      companySize: 88,
      revenue: 90,
      technology: 95,
      engagement: 92
    },
    enrichedData: {
      socialMediaPresence: ['LinkedIn', 'Twitter', 'YouTube'],
      technologies: ['React', 'Node.js', 'AWS', 'PostgreSQL'],
      fundingStatus: 'Series B - $15M raised',
      competitors: ['Zapier', 'Microsoft Power Automate', 'Integromat'],
      recentNews: ['Launched new AI features', 'Expanded to European market']
    },
    priority: 'high',
    status: 'new'
  },
  {
    id: '2',
    companyName: 'GreenLeaf Consulting',
    website: 'https://greenleaf.co',
    industry: 'Consulting',
    employeeCount: '10-50',
    revenue: '$1M-$5M',
    location: 'Austin, TX',
    contactEmail: 'hello@greenleaf.co',
    contactPhone: '+1-555-0456',
    description: 'Sustainability consulting for small to medium businesses',
    score: 76,
    scoreBreakdown: {
      industryMatch: 70,
      companySize: 75,
      revenue: 72,
      technology: 80,
      engagement: 85
    },
    enrichedData: {
      socialMediaPresence: ['LinkedIn', 'Instagram'],
      technologies: ['WordPress', 'Google Analytics', 'HubSpot'],
      fundingStatus: 'Bootstrapped',
      competitors: ['ERM', 'Arcadis', 'WSP'],
      recentNews: ['Won sustainability award', 'New partnership with local government']
    },
    priority: 'medium',
    status: 'contacted'
  },
  {
    id: '3',
    companyName: 'Digital Health Corp',
    website: 'https://digitalhealth.com',
    industry: 'Healthcare',
    employeeCount: '200-500',
    revenue: '$10M-$50M',
    location: 'Boston, MA',
    contactEmail: 'info@digitalhealth.com',
    contactPhone: '+1-555-0789',
    description: 'Telemedicine platform connecting patients with healthcare providers',
    score: 88,
    scoreBreakdown: {
      industryMatch: 92,
      companySize: 85,
      revenue: 88,
      technology: 90,
      engagement: 83
    },
    enrichedData: {
      socialMediaPresence: ['LinkedIn', 'Twitter', 'Facebook'],
      technologies: ['Python', 'Django', 'React', 'MongoDB', 'AWS'],
      fundingStatus: 'Series A - $8M raised',
      competitors: ['Teladoc', 'Amwell', 'MDLive'],
      recentNews: ['FDA approval for new feature', 'Expanded insurance coverage']
    },
    priority: 'high',
    status: 'qualified'
  }
];
